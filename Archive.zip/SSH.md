# SSH Access Details

- **Host**: `145.79.4.36`
- **Port**: `65002`
- **Username**: `u837303424`
- **Password**: `Raph1912!`
- **Public Key**:
  ```
  ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIF8BePFSw6IDLO0gGc+XVWXqNYfysoUEvdfxUJfBGXWu
  ```

> Keep this file confidential. Rotate the password/key if it becomes public.
